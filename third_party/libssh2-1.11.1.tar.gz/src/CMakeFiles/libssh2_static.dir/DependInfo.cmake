
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/workspaces/criper-mcp/third_party/libssh2/src/agent.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/agent.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/agent.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/bcrypt_pbkdf.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/bcrypt_pbkdf.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/bcrypt_pbkdf.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/chacha.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/chacha.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/chacha.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/channel.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/channel.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/channel.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/cipher-chachapoly.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/cipher-chachapoly.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/cipher-chachapoly.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/comp.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/comp.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/comp.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/crypt.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/crypt.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/crypt.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/crypto.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/crypto.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/crypto.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/global.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/global.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/global.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/hostkey.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/hostkey.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/hostkey.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/keepalive.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/keepalive.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/keepalive.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/kex.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/kex.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/kex.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/knownhost.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/knownhost.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/knownhost.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/mac.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/mac.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/mac.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/misc.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/misc.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/misc.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/packet.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/packet.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/packet.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/pem.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/pem.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/pem.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/poly1305.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/poly1305.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/poly1305.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/publickey.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/publickey.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/publickey.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/scp.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/scp.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/scp.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/session.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/session.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/session.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/sftp.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/sftp.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/sftp.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/transport.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/transport.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/transport.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/userauth.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/userauth.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/userauth.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/userauth_kbd_packet.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/userauth_kbd_packet.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/userauth_kbd_packet.c.o.d"
  "/workspaces/criper-mcp/third_party/libssh2/src/version.c" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/version.c.o" "gcc" "third_party/libssh2/src/CMakeFiles/libssh2_static.dir/version.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
